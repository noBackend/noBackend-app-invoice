Backenless Implementation
=========================

The Backenless Implementation for the invoice app has been
brought to you by [backendless.com](http://backendless.com/).

Find more info and instructions on [their blog](https://backendless.com/javascript-invoice-app-with-baas-data-management-user-registration-and-login/)


About Backenless
------------------

Backenless is a Backend-as-a-Service (BaaS) platform enabling the development
of mobile, desktop and web applications. Developers using Backendless
can implement their applications without writing any server-side
code. This is accomplished by exposing the core server-side
functions as services and providing client APIs to access these
services.